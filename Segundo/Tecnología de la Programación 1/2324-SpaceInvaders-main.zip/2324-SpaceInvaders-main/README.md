# Prácticas de TPI del curso 2023-24

- [Enunciado de la Práctica 1](./enunciados/practica1/practica1.md) ([English](./enunciados/practica1/practica1_en.md))
    
    - [Guía de implementación](./enunciados/practica1/GuiaImplementacion.md) ([English](./enunciados/practica1/GuiaImplementacion_en.md))

    - [Plantilla de la práctica 1](https://github.com/informaticaucm-TPI/2324-SpaceInvaders/releases/tag/practica1-plantilla)

- [Enunciado de la Práctica 2 (parte I)](./enunciados/practica2/practica2_1.md) ([English](./enunciados/practica2/assignment2_1.md))

- [Enunciado de la Práctica 2 (parte II)](./enunciados/practica2/practica2_2.md) ([English](./enunciados/practica2/assignment2_2.md))

    - Actualización (02/12/2023): Messajes.java y tests/p2

- [Enunciado de la Práctica 3](./enunciados/practica3/practica3.md) ([English](./enunciados/practica3/assignment3.md))
