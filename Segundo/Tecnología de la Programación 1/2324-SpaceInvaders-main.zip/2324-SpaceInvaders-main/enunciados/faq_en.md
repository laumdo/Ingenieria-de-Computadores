# Frequently Asked Questions

## Assignment 1


### When resetting the game, does the random behaviour have to be the same as at the beginning?

Yes, it is necessary to reuse the seed, which means recreating the Random object with the same seed (`this.random = new Random(this.seed)`).

