package tp1.logic;

public enum Level {
 
	;
	
	//TODO use your enum Level from p1
	
	public static String all(String separator) {
		return null;
	}

	public static Level valueOfIgnoreCase(String string) {
		return null;
	}

	
}