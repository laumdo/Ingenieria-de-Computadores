package tp1.logic;

public enum Move {
	//TODO use your code from P1
}
