package tp1.logic;

public class Position {

	//TODO use your code from P1

	public Position(int col, int row) {
	}
}
