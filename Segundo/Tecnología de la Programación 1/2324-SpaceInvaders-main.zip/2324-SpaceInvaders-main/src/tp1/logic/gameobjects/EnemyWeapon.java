package tp1.logic.gameobjects;

public class EnemyWeapon {

	//TODO fill with your code
	
}
