package tp1.logic.gameobjects;

import tp1.logic.Game;
import tp1.logic.Position;

public class UCMShip {

	//TODO fill with your code

	public UCMShip(Game game, Position position) {
		//TODO fill with your code
	}
	
	//TODO fill with your code
}
