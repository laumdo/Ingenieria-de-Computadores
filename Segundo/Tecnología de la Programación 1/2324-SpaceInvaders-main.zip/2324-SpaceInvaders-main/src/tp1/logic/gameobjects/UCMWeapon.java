package tp1.logic.gameobjects;

public class UCMWeapon {

	//TODO fill with your code

}
